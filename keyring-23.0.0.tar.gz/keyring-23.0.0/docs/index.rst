Welcome to |project| documentation!
===================================

.. include:: ../README.rst 

.. toctree::
   :maxdepth: 1

   history


.. automodule:: keyring
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

